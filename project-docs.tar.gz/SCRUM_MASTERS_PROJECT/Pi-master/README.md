# Pi
This is the repo for each pi's config
