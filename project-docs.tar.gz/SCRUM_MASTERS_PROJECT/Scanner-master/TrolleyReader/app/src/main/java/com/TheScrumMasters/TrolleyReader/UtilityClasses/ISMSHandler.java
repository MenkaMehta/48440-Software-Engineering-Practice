package com.TheScrumMasters.TrolleyReader.UtilityClasses;

/**
 * Created by ryan on 20/09/16.
 */
public interface ISMSHandler
{
    void SMSReceived(String message);
}
