###Android Component
## Notes:
You CANNOT, I'll repeat CANNOT send messages to multiple people.

